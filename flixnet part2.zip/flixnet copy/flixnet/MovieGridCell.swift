//
//  MovieGridCell.swift
//  flixnet
//
//  Created by Peter Jung on 1/27/19.
//  Copyright © 2019 Peter Jung. All rights reserved.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
